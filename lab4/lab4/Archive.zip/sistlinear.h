
int* fatoracao (int n, double** A);
double* substituicao (int n, double** A, int* p, double* b);
