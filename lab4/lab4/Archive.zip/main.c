#include "sistlinear.h" 
#include <stdio.h> 
#include <stdlib.h> 
#include "lab0.h" 
#include <math.h>

#define TAM 3 

int main(){
	

    int *vet;
    double **m = matcria(3, 3);
    double *x;
    double b[3];
    
    b[0] = 3;
    b[1] = 3;
    b[2] = -6;
    
    m[0][0] = 1;
    m[0][1] = 2;
    m[0][2]= -1;
    
    m[1][0] = 2;
    m[1][1] = 1;
    m[1][2]= -2;
    m[2][0] = -3;
    m[2][1] = 1;
    m[2][2]= 1;
    
    matimprime(3, 3 , m , "%.2lf");

    vet = fatoracao (3, m);
    matimprime(3, 3 , m , "%0.2lf");
    x = substituicao (3, m, vet,b);
    vetimprime(3, x , "%0.2lf" );
    

    vetlibera(x);
    matlibera(3,m);
	return 0;
}
